//
//  Language.h
//  DynamicArray
//
//  Created by 郭瑞泽 on 2022/3/26.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Language : NSObject

@end

NS_ASSUME_NONNULL_END
