//
//  My_Assert.h
//  DynamicArray
//
//  Created by 郭瑞泽 on 2022/3/19.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface My_Assert : NSObject
+ (void)test:(BOOL)value;
@end

NS_ASSUME_NONNULL_END
